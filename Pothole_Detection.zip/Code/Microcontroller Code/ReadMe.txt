Folder Name: akhil_esp_only
This contains ESP 8266 which will take data from accelerometer and if the received data crosses threshold value, it will get GPS values and sends it over Wi-Fi.