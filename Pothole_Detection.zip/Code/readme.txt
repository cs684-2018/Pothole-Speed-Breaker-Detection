2018 - CS684  Group X : Project README TEMPLATE 
================================================ 
 
Group Info: 
------------ 
+   Hitesh Kurapati (173079007)
+   Akhil Gakhar (173079027)
+   Abhishek Kumar (173079006) 
 
 
 
Project Description 
------------------- 
In this project we intend to identify potholes through sudden jerks felt while driving a vehicle, locating the same and provide a continuous plot of the potholes on Google Maps using appropriate markers.
 
 
Technologies Used 
------------------- 
 
Remove the items that do no apply to your project and keep the remaining ones. 
 
+   Embedded C for TIVA
+   JAVA 
+   Python 
+   Android 
+   Specialized Hardware like ESP 8266, Accelerometer ADXL 335, GPS Module MT3329     
 
 
Installation Instructions 
========================= 
 
These softwares can be installed easily. Please refer to the videos uploaded for further instructions.
 
Demonstration Video 
=========================  
Add the youtube link of the screencast of your project demo.

https://youtu.be/4AfzTzpfA2g

https://youtu.be/gwLRXrsvKrY

https://youtu.be/odXq9oLcU14

References 
=========== 
 
Please give references to importance resources.  
 
+ https://developer.android.com/studio/
+ https://developers.google.com/
+ https://www.arduino.cc/en/Main/Software
