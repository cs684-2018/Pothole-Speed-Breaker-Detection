Project Name:
Pothole Detection


Team Members:

1. Hitesh Kurapati (173079007)

2. Akhil Gakhar (173079027)

3. Abhishek Kumar (173079006)

4. 

Project Description:

  Creating a reliable system which will alert the driver in prior about potholes in turn will serve purpose of saving peoples� life. This system does it exactly by uploading the detected potholes on to Google Maps. The system have Accelerometer sensor which will detect the potholes when a vehicle pass through a pothole. This system also have Wi-Fi module which gets the location data from GPS module and communicates with the Android application which in turn will be uploading on to the Google Maps. 